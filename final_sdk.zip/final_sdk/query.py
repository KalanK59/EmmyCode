import hashlib
import base64
from urllib import request
import xml.etree.ElementTree as ET
import os
import requests
from datetime import datetime
from dotenv import load_dotenv
load_dotenv()  #for env setup credentials in .env files

# Declaring credentials 
REGISTRY_KEY = os.getenv('EIDR_REGISTRY_KEY', '')
EIDR_LOGIN = os.getenv('EIDR_LOGIN', '')
EIDR_PARTYID = os.getenv('EIDR_PARTYID', '')
EIDR_PASSWORD = os.getenv('EIDR_PASSWORD', '')

# Basic settings
requestPagesize = 1000
QueryPageOffset = 1

def get_timestamp():
    return datetime.now().strftime("%Y%m%d_%H%M%S")

# Query Picker to save time and sweat
def get_queries():
    if not os.path.exists("queries"):
        print("Error: queries directory not found!")
        return None
    
    query_files = {}
    # Get all txt files
    for file in os.listdir("queries"):
        if file.endswith(".txt"):
            try:
                with open(f"queries/{file}", "r", encoding='utf-8') as f:  
                    query_files[file] = f.read().strip()  
            except Exception as e:  
                print(f"Cannot read file {file}: {e}")
    
    if not query_files:  
        print("No query files found in queries directory")
    
    return query_files

def pick_query(queries):
    '''This function will work when we have a queries directory with various queries saved in them as a txt file in order to run !
    This was done to test and run multiple queries and save some time !'''

    if not queries:
        return None
    
    print("\nAvailable queries:") 
    files = list(queries.keys())
    
    for i in range(len(files)):
        print(f"{i+1}: {files[i]}")
    
    try:
        choice = input("\nChoose : ")  
        choice_idx = int(choice) - 1
        if 0 <= choice_idx < len(files):
            return queries[files[choice_idx]]
        else:
            print("Invalid choice: number out of range")
            return None
    except ValueError:
        print("Invalid input: please enter a number")
        return None
    except Exception as e:
        print(f"Error: {e}")
        return None

def getQueryBody():
    # Check if credentials are set
    if not all([REGISTRY_KEY, EIDR_LOGIN, EIDR_PARTYID, EIDR_PASSWORD]):
        print("Error: EIDR credentials not set in environment variables")
        return None

    queries = get_queries()
    if not queries:
        return None
    
    query = pick_query(queries)
    if not query:
        return None

    #XMLing the request 
    xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<Request xmlns="http://www.eidr.org/schema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Operation>
    <Query>
      <Expression>({query})</Expression>
      <PageNumber>{QueryPageOffset}</PageNumber>
      <PageSize>{requestPagesize}</PageSize>
    </Query>
  </Operation>
</Request>'''
    
# Auth stuff       
    try:
        pw = bytes(EIDR_PASSWORD, 'utf-8')
        hashed = hashlib.sha256(pw)
        encoded = base64.b64encode(hashed.digest())
        auth = f'Eidr {EIDR_LOGIN}:{EIDR_PARTYID}:{str(encoded, encoding="utf-8")}'
        
        # Sending request
        headers = {
            'Content-Type': 'text/xml', 
            'Authorization': auth,
            'Accept': 'text/xml'
        }
        
        body = bytes(xml, 'utf-8')
        url = f'https://{REGISTRY_KEY}.eidr.org/EIDR/query/?type=ID'
        req = request.Request(url, headers=headers, data=body)
        
        response = request.urlopen(req)
        return response.read() if response else None
        
    except Exception as e:
        print(f"Error in query request: {e}")
        return None

def get_ids(xml_data):
    try:
        root = ET.fromstring(xml_data)
        ids = []
        
        for id in root.findall('.//eidr:ID', {'eidr': 'http://www.eidr.org/schema'}):
            ids.append(id.text.strip())
        
        if not ids:  # Check if we found any IDs
            print("Warning: No IDs found in XML response")
            
        return ids
    except ET.ParseError as e:
        print(f"XML parsing error: {e}")
        return []
    except Exception as e:
        print(f"Error while processing XML: {e}")
        return []
    
#TODO : Add some kind of logging

#This is to fetch XML from the ids we got
def get_metadata(eidr_id):
    url = f'https://resolve.eidr.org/EIDR/object/{eidr_id}'
    try:
        response = requests.get(url, timeout=10)  # Added timeout
        if response.status_code == 200:
            return response.text
        else:
            print(f'Error getting metadata: {response.status_code} for {eidr_id}')
            return None
    except requests.Timeout:
        print(f'Request timed out for {eidr_id}')
        return None
    except Exception as e:
        print(f'Failed to fetch {eidr_id}: {e}')
        return None

def save_metadata(eidr_id, metadata, timestamp):
    folder = os.path.join('testdata', timestamp)
    try:
        if not os.path.exists(folder):
            os.makedirs(folder)

        filename = eidr_id.replace("/", "_") + ".xml"
        filepath = os.path.join(folder, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(metadata)
        print(f'Saved: {filepath}')
        return True  # Added return value for success
    except Exception as e:
        print(f'Failed to write metadata for {eidr_id}: {e}')
        return False

def main():
    #Using timestamps as a unique identifier for query running
    timestamp = get_timestamp()
    
    # Get initial response
    response = getQueryBody()

    if response:
        ids = get_ids(response)        
        if not ids:
            print("No IDs found, exiting.")
            return
            
        ids_folder = 'IDs'
        if not os.path.exists(ids_folder):
            os.makedirs(ids_folder)
            
        try:
            ids_filename = f'eidr_ids_{timestamp}.txt'
            ids_filepath = os.path.join(ids_folder, ids_filename)
            with open(ids_filepath, "w", encoding='utf-8') as f:
                for id in ids:
                    f.write(f"{id}\n")
            print(f"\nSaved IDs to: {ids_filepath}")
            
            #Looping through txt file to fetch full XML data
            print("\nFetching metadata for each ID...")
            success_count = 0
            for id in ids:
                metadata = get_metadata(id)
                if metadata and save_metadata(id, metadata, timestamp):
                    success_count += 1
                    
            print(f"\nProcessed {success_count} out of {len(ids)} IDs successfully")
            
        except Exception as e:
            print(f"Error writing IDs file: {e}")
    
if __name__ == "__main__":
    main()

#TODO : Add the XML to JSON extractor for Lambda