#!/usr/bin/env python3
"""
EIDR Language Processing CLI - Command Line Interface for the EIDR Language Processing SDK
"""

import argparse
import json
import sys

# Import the SDK (assuming it's in a file named sdk_client.py)
try:
    from sdk_client import EIDRSDK, logger
except ImportError:
    print("Error: EIDR Language SDK not found.")
    print("Make sure the SDK file is in the same directory or in your PYTHONPATH.")
    sys.exit(1)


def setup_parser() -> argparse.ArgumentParser:
    """Set up command line argument parser."""
    parser = argparse.ArgumentParser(
        description="EIDR Language Processing CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Command to execute')
    
    parent_parser = argparse.ArgumentParser(add_help=False)
    parent_parser.add_argument(
        '--verbose', 
        action='store_true', 
        help='Enable verbose output'
    )
    
    identify_parser = subparsers.add_parser('identify', parents=[parent_parser], help='Identify language of a title')
    identify_parser.add_argument('title', help='Title to process')
    
    translate_parser = subparsers.add_parser('translate', parents=[parent_parser], help='Translate a title to English')
    translate_parser.add_argument('title', help='Title to translate')
    translate_parser.add_argument('--language', help='Source language (optional)')
    
    transliterate_parser = subparsers.add_parser('transliterate', parents=[parent_parser], help='Transliterate a title')
    transliterate_parser.add_argument('title', help='Title to transliterate')
    transliterate_parser.add_argument('--language', help='Source language (optional)')
    
    score_parser = subparsers.add_parser('score', parents=[parent_parser], help='Score a title against expected language')
    score_parser.add_argument('title', help='Title to score')
    score_parser.add_argument('--language', required=True, help='Expected language')
    
    process_id_parser = subparsers.add_parser('process-id', parents=[parent_parser], help='Process a single EIDR ID')
    process_id_parser.add_argument('eidr_id', help='EIDR ID to process')
    process_id_parser.add_argument('--output', help='Output file for results (JSON)')
    
    # process_file_parser = subparsers.add_parser('process-file', parents=[parent_parser], help='Process a file of EIDR IDs')
    # process_file_parser.add_argument('file_path', help='Path to file with EIDR IDs')
    # process_file_parser.add_argument('--output', help='Output file for results (JSON)')
    # process_file_parser.add_argument('--max-workers', type=int, help='Maximum concurrent workers')
    
    # query_parser = subparsers.add_parser('query', parents=[parent_parser], help='Run interactive query and process results')
    # query_parser.add_argument('--output', help='Output file for results (JSON)')
    # query_parser.add_argument('--id-file', help='File containing EIDR IDs')
    # query_parser.add_argument('--max-workers', type=int, help='Maximum concurrent workers')
    
    return parser


def pretty_print(data):
    """Print data in a formatted way."""
    print(json.dumps(data, indent=2, ensure_ascii=False))


def main() -> None:
    """Main CLI entry point."""
    parser = setup_parser()
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    if hasattr(args, 'verbose') and args.verbose:
        logger.setLevel("DEBUG")
    
    sdk = EIDRSDK()
    
    if args.command == 'identify':
        result = sdk.identify_language(args.title)
        pretty_print(result)
        
    elif args.command == 'translate':
        result = sdk.translate(args.title, args.language)
        pretty_print(result)
        
    elif args.command == 'transliterate':
        result = sdk.transliterate(args.title, args.language)
        pretty_print(result)
        
    elif args.command == 'score':
        result = sdk.score_language(args.title, args.language)
        pretty_print(result)
        
    elif args.command == 'process-id':
        result = sdk.process_single_id(args.eidr_id)
        pretty_print(result)
        if args.output:
            sdk.file_processor.save_results_to_file({args.eidr_id: result}, args.output)
            print(f"Results saved to {args.output}")
        
    elif args.command == 'process-file':
        sdk.process_id_file(
            args.file_path,
            output_file=args.output,
            max_workers=args.max_workers
        )
        
    elif args.command == 'query':
        sdk.run_query_and_process(
            output_file=args.output,
            id_file=args.id_file,
            max_workers=args.max_workers
        )


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nOperation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
