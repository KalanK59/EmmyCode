"""
EIDR Language Processing SDK - A focused SDK for processing entertainment content IDs,
performing language identification, translation, and storing results.
Includes functionality to process ID files using AWS Lambda.
"""

import hashlib
import base64
import requests
import json
import xml.etree.ElementTree as ET
import os
from pathlib import Path
import logging
from typing import Dict, List, Optional, Tuple, Union, Any
import boto3
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("eidr_language.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("eidr_language")


class Config:
    """Configuration for the SDK."""
    
    def __init__(self, env_file: Optional[str] = None):
        """
        Initialize configuration from environment variables or .env file.
        
        Args:
            env_file: Path to .env file (optional)
        """
        # Load .env file if provided
        if env_file and os.path.exists(env_file):
            self._load_env_file(env_file)
        else:
            # Try to load default .env file if it exists
            if os.path.exists('.env'):
                self._load_env_file('.env')
            
        # EIDR Configuration
        self.eidr_registry_key = os.environ.get('EIDR_REGISTRY_KEY', '')
        self.eidr_login = os.environ.get('EIDR_LOGIN', '')
        self.eidr_party_id = os.environ.get('EIDR_PARTYID', '')
        self.eidr_password = os.environ.get('EIDR_PASSWORD', '')
        
        # OpenAI Configuration
        self.openai_api_key = os.environ.get('OPENAI_API_KEY', '')
        
        # AWS Lambda Configuration
        self.lambda_function_name = os.environ.get('LAMBDA_FUNCTION_NAME', '')
        self.aws_region = os.environ.get('AWS_REGION', os.environ.get('AWS_DEFAULT_REGION', ''))
        
        # Processing settings
        self.timeout = int(os.environ.get('REQUEST_TIMEOUT', '10'))
        self.max_workers = int(os.environ.get('MAX_WORKERS', '10'))  # For parallel processing
        
        # Log configuration status
        self._log_config_status()
    
    def _load_env_file(self, file_path: str) -> None:
        """Load environment variables from a .env file."""
        try:
            logger.info(f"Loading environment variables from {file_path}")
            with open(file_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#') or '=' not in line:
                        continue
                    key, value = line.split('=', 1)
                    key = key.strip()
                    value = value.strip().strip('"\'')
                    os.environ[key] = value
                    # Avoid logging sensitive values
                    if 'KEY' in key or 'PASSWORD' in key or 'SECRET' in key:
                        logger.debug(f"Set {key}=********")
                    else:
                        logger.debug(f"Set {key}={value}")
        except Exception as e:
            logger.error(f"Failed to load .env file: {e}")
            
    def _log_config_status(self) -> None:
        """Log the configuration status."""
        missing = []
        
        # Check EIDR credentials
        if not self.eidr_registry_key:
            missing.append("EIDR_REGISTRY_KEY")
        if not self.eidr_login:
            missing.append("EIDR_LOGIN")
        if not self.eidr_party_id:
            missing.append("EIDR_PARTYID")
        if not self.eidr_password:
            missing.append("EIDR_PASSWORD")
            
        # Check language processing configuration
        if not self.openai_api_key and not self.lambda_function_name:
            missing.append("Either OPENAI_API_KEY or LAMBDA_FUNCTION_NAME is required")
        
        # Check AWS configuration if Lambda is enabled
        if self.lambda_function_name and not self.aws_region:
            missing.append("AWS_REGION or AWS_DEFAULT_REGION (when using Lambda)")
            
        # Log status
        if missing:
            logger.warning(f"Incomplete configuration: missing {', '.join(missing)}")
        else:
            logger.info("Configuration complete")
            
        # Log which processing methods are available
        available_methods = []
        if self.openai_api_key:
            available_methods.append("OpenAI")
        if self.lambda_function_name:
            available_methods.append("AWS Lambda")
            
        if available_methods:
            logger.info(f"Available processing methods: {', '.join(available_methods)}")
        else:
            logger.warning("No processing methods available")


class EIDRClient:
    """Client for retrieving EIDR metadata."""
    
    def __init__(self, config: Optional[Config] = None):
        """
        Initialize the EIDR client.
        
        Args:
            config: SDK configuration
        """
        self.config = config or Config()
        self.namespace = {'ns2': 'http://www.eidr.org/schema'}
        self.eidr_namespace = {'eidr': 'http://www.eidr.org/schema'}
    
    def get_auth_header(self) -> str:
        """Generate EIDR authorization header."""
        pw = bytes(self.config.eidr_password, 'utf-8')
        hashed = hashlib.sha256(pw)
        encoded = base64.b64encode(hashed.digest())
        return f'Eidr {self.config.eidr_login}:{self.config.eidr_party_id}:{str(encoded, encoding="utf-8")}'
    
    def get_metadata(self, eidr_id: str) -> Optional[str]:
        """
        Retrieve metadata for a single EIDR ID.
        
        Args:
            eidr_id: EIDR ID to retrieve
            
        Returns:
            XML metadata as string, or None if retrieval failed
        """
        url = f'https://resolve.eidr.org/EIDR/object/{eidr_id}'
        try:
            response = requests.get(url, timeout=self.config.timeout)
            if response.status_code == 200:
                return response.text
            logger.warning(f'Failed to retrieve {eidr_id} (status code: {response.status_code})')
        except requests.Timeout:
            logger.warning(f'Request timeout for {eidr_id}')
        except Exception as e:
            logger.error(f'Error retrieving {eidr_id}: {e}')
        return None
    
    def extract_titles(self, xml_string: str) -> Dict:
        """
        Extract title information from EIDR metadata XML.
        
        Args:
            xml_string: XML metadata from EIDR
            
        Returns:
            Dictionary containing record_id, primary_title, and alternate_titles
        """
        if not xml_string:
            return {"record_id": None, "primary_title": None, "alternate_titles": []}
                
        try:
            root = ET.fromstring(xml_string)
            base_object = root.find('.//ns2:BaseObjectData', self.namespace)
            
            if base_object is None:
                return {"record_id": None, "primary_title": None, "alternate_titles": []}
            
            # Extract record ID
            record_id_elem = base_object.find('ns2:ID', self.namespace)
            record_id = record_id_elem.text if record_id_elem is not None else None
            
            # Extract primary title
            primary_name = base_object.find('ns2:ResourceName', self.namespace)
            primary_title = {
                "text": primary_name.text if primary_name is not None else None,
                "language": primary_name.get("lang") if primary_name is not None else None
            }
            
            # Extract alternate titles
            alternate_titles = []
            for alt_name in base_object.findall('ns2:AlternateResourceName', self.namespace):
                if alt_name is not None and alt_name.text:
                    alternate_titles.append({
                        "text": alt_name.text,
                        "language": alt_name.get("lang")
                    })
            
            return {
                "record_id": record_id,
                "primary_title": primary_title,
                "alternate_titles": alternate_titles
            }
                
        except ET.ParseError as e:
            logger.error(f"XML parsing failed: {e}")
            return {"record_id": None, "primary_title": None, "alternate_titles": []}
        except Exception as e:
            logger.error(f"Title extraction error: {e}")
            return {"record_id": None, "primary_title": None, "alternate_titles": []}


class LanguageProcessor:
    """Process language data for titles."""
    
    def __init__(self, config: Optional[Config] = None):
        """
        Initialize the language processor.
        
        Args:
            config: SDK configuration
        """
        self.config = config or Config()
        self.lambda_client = None
        
        # Create Lambda client if Lambda function name is provided
        if self.config.lambda_function_name:
            try:
                # Set region explicitly if available
                kwargs = {}
                if self.config.aws_region:
                    kwargs['region_name'] = self.config.aws_region
                
                self.lambda_client = boto3.client('lambda', **kwargs)
                logger.info(f"AWS Lambda client initialized for function: {self.config.lambda_function_name}")
                
                # Test the Lambda connection
                self._test_lambda_connection()
            except Exception as e:
                logger.error(f"Failed to initialize AWS Lambda client: {e}")
                logger.info("Will use OpenAI for language processing instead")
                self.lambda_client = None
    
    def _test_lambda_connection(self):
        """Test the Lambda connection by getting the function configuration."""
        try:
            # Get function configuration as a lightweight test
            response = self.lambda_client.get_function(
                FunctionName=self.config.lambda_function_name
            )
            logger.info(f"Successfully connected to Lambda function: {self.config.lambda_function_name}")
            # Log some basic info about the function
            runtime = response.get('Configuration', {}).get('Runtime', 'unknown')
            memory = response.get('Configuration', {}).get('MemorySize', 'unknown')
            logger.info(f"Function details - Runtime: {runtime}, Memory: {memory}MB")
            
        except self.lambda_client.exceptions.ResourceNotFoundException:
            logger.error(f"Lambda function {self.config.lambda_function_name} not found")
            self.lambda_client = None
            
        except Exception as e:
            logger.error(f"Error testing Lambda connection: {e}")
            logger.error("Lambda processing will be unavailable")
    
    def identify_language(self, title: str) -> Dict:
        """
        Identify the language of a title without translation/transliteration.
        
        Args:
            title: Title text
            
        Returns:
            Language identification data
        """
        result = self._process_with_openai(title, "identify_only")
        return {
            "DetectedLanguage": result.get("DetectedLanguage"),
            "ISO639LanguageCode": result.get("ISO639LanguageCode"),
            "Confidence": result.get("Confidence")
        }
    
    def translate_only(self, title: str, source_language: Optional[str] = None) -> Dict:
        """
        Translate a title to English.
        
        Args:
            title: Title text
            source_language: Source language (optional)
            
        Returns:
            Translation data
        """
        result = self._process_with_openai(title, "translate_only", source_language)
        return {
            "OriginalTitle": title,
            "SourceLanguage": source_language or result.get("DetectedLanguage"),
            "Translation": result.get("Translation")
        }
    
    def transliterate_only(self, title: str, source_language: Optional[str] = None) -> Dict:
        """
        Transliterate a title to Latin characters.
        
        Args:
            title: Title text
            source_language: Source language (optional)
            
        Returns:
            Transliteration data
        """
        result = self._process_with_openai(title, "transliterate_only", source_language)
        return {
            "OriginalTitle": title,
            "SourceLanguage": source_language or result.get("DetectedLanguage"),
            "Transliteration": result.get("Transliteration")
        }
    
    def score_language(self, title: str, expected_language: str) -> Dict:
        """
        Score the likelihood that a title is in the expected language.
        
        Args:
            title: Title text
            expected_language: Expected language
            
        Returns:
            Language confidence score
        """
        result = self._process_with_openai(title, "score_language", expected_language)
        return {
            "OriginalTitle": title,
            "ExpectedLanguage": expected_language,
            "DetectedLanguage": result.get("DetectedLanguage"),
            "Confidence": result.get("Confidence"),
            "Match": expected_language.lower() == result.get("DetectedLanguage", "").lower()
        }
    
    def process_title(self, record_id: str, title: str, 
                     original_language: Optional[str] = None) -> Dict:
        """
        Process a title with full language analysis.
        
        Args:
            record_id: Record ID
            title: Title text
            original_language: Original language (optional)
            
        Returns:
            Full language analysis
        """
        # Check if Lambda processing is available and should be used
        if self.lambda_client and self.config.lambda_function_name:
            return self._process_with_lambda(record_id, title, original_language)
        
        # Fallback to OpenAI processing
        return self._process_with_openai(title, "full", original_language)
    
    def _process_with_lambda(self, record_id: str, title: str, 
                           original_language: Optional[str] = None) -> Dict:
        """
        Process a title using AWS Lambda.
        
        Args:
            record_id: Record ID
            title: Title text
            original_language: Original language (optional)
            
        Returns:
            Lambda processing result
        """
        try:
            # Check for AWS region
            if 'AWS_REGION' not in os.environ and 'AWS_DEFAULT_REGION' not in os.environ:
                logger.warning("AWS region not set in environment variables")
                # Attempt to set a default region to avoid common errors
                os.environ['AWS_DEFAULT_REGION'] = 'us-east-1'
                
            # Log Lambda invocation attempt
            logger.info(f"Invoking Lambda function: {self.config.lambda_function_name}")
            logger.info(f"Processing record: {record_id}, title: {title}, language: {original_language}")
            
            # Prepare the payload
            payload = {
                'RecordID': record_id,
                'Title': title,
                'OriginalLanguage': original_language or "",
            }
            
            # Invoke Lambda function
            response = self.lambda_client.invoke(
                FunctionName=self.config.lambda_function_name,
                InvocationType='RequestResponse',
                Payload=json.dumps(payload)
            )
            
            # Check Lambda execution status
            status_code = response.get('StatusCode')
            if status_code != 200:
                logger.error(f"Lambda returned non-200 status code: {status_code}")
                return {"error": f"Lambda function failed with status code: {status_code}"}
                
            # Check for Lambda function error
            if 'FunctionError' in response:
                error_type = response.get('FunctionError')
                logger.error(f"Lambda function error: {error_type}")
                
                # Get detailed error message from payload
                error_payload = json.loads(response['Payload'].read().decode('utf-8'))
                logger.error(f"Lambda error details: {error_payload}")
                
                return {"error": f"Lambda function error: {error_type}", "details": error_payload}
            
            # Parse the successful response
            response_payload = json.loads(response['Payload'].read().decode('utf-8'))
            
            # Add some debug info
            logger.info(f"Lambda processing successful for {record_id}")
            
            return response_payload
            
        except boto3.exceptions.Boto3Error as e:
            logger.error(f"AWS boto3 error: {e}")
            # Log more details about the error
            logger.error(f"Error type: {type(e).__name__}")
            logger.error(f"Error details: {str(e)}")
            # Fallback to OpenAI if Lambda fails
            logger.info(f"Falling back to OpenAI for {record_id}")
            return self._process_with_openai(title, "full", original_language)
            
        except Exception as e:
            logger.error(f"Lambda processing error: {e}")
            # Log traceback for more detailed debugging
            import traceback
            logger.error(f"Traceback: {traceback.format_exc()}")
            # Fallback to OpenAI if Lambda fails
            logger.info(f"Falling back to OpenAI for {record_id}")
            return self._process_with_openai(title, "full", original_language)
    
    def _process_with_openai(self, title: str, mode: str = "full", 
                            language_hint: Optional[str] = None) -> Dict:
        """Process a title directly with OpenAI API."""
        try:
            import openai
            from openai import OpenAI
            
            if not self.config.openai_api_key:
                return {"error": "OpenAI API key not configured"}
                
            # Initialize OpenAI client
            client = OpenAI(api_key=self.config.openai_api_key)
            
            # Choose appropriate prompt based on mode
            if mode == "identify_only":
                prompt = f"Given the title: '{title}', detect the language both by name and ISO 639 language code. Provide a confidence score between 0 and 1 for the language detection. Return JSON with keys: DetectedLanguage, ISO639LanguageCode, Confidence."
            elif mode == "translate_only":
                prompt = f"Given the title: '{title}' in {language_hint or 'an unknown language'}, translate it to English. Return JSON with keys: DetectedLanguage, Translation."
            elif mode == "transliterate_only":
                prompt = f"Given the title: '{title}' in {language_hint or 'an unknown language'}, provide a transliteration into the Latin-1 character set. Return JSON with keys: DetectedLanguage, Transliteration."
            elif mode == "score_language":
                prompt = f"Given the title: '{title}', determine if it is in {language_hint} language. Provide a confidence score between 0 and 1. Return JSON with keys: DetectedLanguage, Confidence."
            else:  # full analysis
                prompt = f"Given the title: '{title}', detect the language both by name and ISO 639 language code, provide a transliteration into the Latin-1 character set, and translate it to English. Return JSON with keys: DetectedLanguage, ISO639LanguageCode, Confidence, Transliteration, Translation."
            
            # System prompt
            system_prompt = "You are an expert language model trained to detect languages, provide transliterations, and generate translations for movie titles. Return only JSON format without explanations or markdown formatting."
            
            # Making the API call
            response = client.chat.completions.create(
                model="gpt-4o-mini", 
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt}
                ],
                temperature=0  # Deterministic output
            )
            
            # Fetch the message from the response
            response_content = response.choices[0].message.content.strip()
            
            # Convert from JSON string to object
            parsed_result = json.loads(response_content)
            
            return parsed_result
            
        except ImportError:
            return {"error": "OpenAI package not installed"}
        except json.JSONDecodeError:
            return {"error": "Failed to parse OpenAI response"}
        except Exception as e:
            return {"error": str(e)}


class FileProcessor:
    """Process files for output."""
    
    def __init__(self, config: Optional[Config] = None):
        """
        Initialize the file processor.
        
        Args:
            config: SDK configuration
        """
        self.config = config or Config()
    
    def save_results_to_file(self, results: Dict, filepath: str) -> bool:
        """
        Save processing results to a JSON file.
        
        Args:
            results: Processing results
            filepath: Output filepath
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
                
            logger.info(f"Results saved to {filepath}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to save results: {e}")
            return False
    
    def get_ids_from_file(self, file_path: str) -> List[str]:
        """
        Load EIDR IDs from a file.
        
        Args:
            file_path: Path to the file containing EIDR IDs
            
        Returns:
            List of EIDR IDs
        """
        try:
            if not os.path.exists(file_path):
                logger.error(f"File not found: {file_path}")
                return []
                
            with open(file_path, 'r') as file:
                # Read all lines, strip whitespace, and filter out empty lines
                ids = [line.strip() for line in file.readlines() if line.strip()]
                logger.info(f"Loaded {len(ids)} IDs from {file_path}")
                return ids
                
        except Exception as e:
            logger.error(f"Error reading file: {e}")
            return []
    
    def save_ids(self, ids: List[str], folder: str = 'IDs') -> Optional[str]:
        """
        Save extracted IDs to a file.
        
        Args:
            ids: List of EIDR IDs to save
            folder: Directory to save the file
            
        Returns:
            Path to the saved file, or None if saving failed
        """
        if not ids:
            logger.warning("No IDs to save")
            return None
            
        try:
            # Create directory if it doesn't exist
            os.makedirs(folder, exist_ok=True)
            
            # Generate timestamp for filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filepath = os.path.join(folder, f"eidr_ids_{timestamp}.txt")
            
            with open(filepath, 'w', encoding='utf-8') as f:
                for id in ids:
                    f.write(f"{id}\n")
                    
            logger.info(f"Saved {len(ids)} IDs to {filepath}")
            return filepath
            
        except Exception as e:
            logger.error(f"Failed to save IDs: {e}")
            return None


class BatchProcessor:
    """Process batches of EIDR IDs."""
    
    def __init__(self, sdk):
        """
        Initialize the batch processor.
        
        Args:
            sdk: EIDRSDK instance
        """
        self.sdk = sdk
        self.config = sdk.config
    
    def process_single_id(self, eidr_id: str) -> Optional[Dict]:
        """
        Process a single EIDR ID.
        
        Args:
            eidr_id: EIDR ID to process
            
        Returns:
            Processed data
        """
        try:
            metadata_xml = self.sdk.eidr_client.get_metadata(eidr_id)
            if not metadata_xml:
                logger.warning(f"Failed to retrieve metadata for {eidr_id}")
                return None
                
            titles = self.sdk.eidr_client.extract_titles(metadata_xml)
            if not titles["record_id"]:
                logger.warning(f"Failed to extract titles for {eidr_id}")
                return None
                
            # Process primary title
            primary_result = {}
            if titles["primary_title"] and titles["primary_title"]["text"]:
                primary_result = self.sdk.language_processor.process_title(
                    titles["record_id"],
                    titles["primary_title"]["text"],
                    titles["primary_title"]["language"]
                )
                
            # Process alternate titles
            alt_results = []
            for alt_title in titles["alternate_titles"]:
                if alt_title["text"]:
                    result = self.sdk.language_processor.process_title(
                        titles["record_id"],
                        alt_title["text"],
                        alt_title["language"]
                    )
                    alt_results.append({
                        "title": alt_title,
                        "analysis": result
                    })
                    
            return {
                "eidr_id": eidr_id,
                "record_id": titles["record_id"],
                "primary_title": {
                    "title": titles["primary_title"],
                    "analysis": primary_result
                },
                "alternate_titles": alt_results
            }
            
        except Exception as e:
            logger.error(f"Error processing {eidr_id}: {e}")
            return None
    
    def process_batch(self, ids: List[str], output_file: Optional[str] = None) -> Dict:
        """
        Process a batch of EIDR IDs using parallel execution.
        
        Args:
            ids: List of EIDR IDs to process
            output_file: Path to save results (optional)
            
        Returns:
            Processing results and statistics
        """
        if not ids:
            logger.warning("No IDs to process")
            return {"processed": 0, "failed": 0, "results": []}
            
        processed_results = []
        failed_ids = []
        
        with ThreadPoolExecutor(max_workers=self.config.max_workers) as executor:
            future_to_id = {executor.submit(self.process_single_id, eid): eid for eid in ids}
            
            for i, future in enumerate(as_completed(future_to_id), 1):
                eid = future_to_id[future]
                try:
                    result = future.result()
                    if result:
                        processed_results.append(result)
                    else:
                        failed_ids.append(eid)
                        
                    # Log progress periodically
                    if i % 10 == 0 or i == len(ids):
                        logger.info(f"Processed {i}/{len(ids)} IDs")
                        
                except Exception as e:
                    logger.error(f"Error with future for {eid}: {e}")
                    failed_ids.append(eid)
        
        # Save results if output file is specified
        if output_file and processed_results:
            output_data = {
                "timestamp": datetime.now().isoformat(),
                "total": len(ids),
                "processed": len(processed_results),
                "failed": len(failed_ids),
                "results": processed_results
            }
            self.sdk.file_processor.save_results_to_file(output_data, output_file)
        
        return {
            "processed": len(processed_results),
            "failed": len(failed_ids),
            "failed_ids": failed_ids,
            "results": processed_results
        }


class EIDRSDK:
    """Main SDK class that provides access to all components."""
    
    def __init__(self, env_file: Optional[str] = None):
        """
        Initialize the SDK.
        
        Args:
            env_file: Path to .env file (optional)
        """
        self.config = Config(env_file)
        self.eidr_client = EIDRClient(self.config)
        self.language_processor = LanguageProcessor(self.config)
        self.file_processor = FileProcessor(self.config)
        self.batch_processor = BatchProcessor(self)
    
    def identify_language(self, title: str) -> Dict:
        """
        Identify the language of a title.
        
        Args:
            title: Title text
            
        Returns:
            Language identification data
        """
        return self.language_processor.identify_language(title)
    
    def translate(self, title: str, source_language: Optional[str] = None) -> Dict:
        """
        Translate a title to English.
        
        Args:
            title: Title text
            source_language: Source language (optional)
            
        Returns:
            Translation data
        """
        return self.language_processor.translate_only(title, source_language)
    
    def transliterate(self, title: str, source_language: Optional[str] = None) -> Dict:
        """
        Transliterate a title to Latin characters.
        
        Args:
            title: Title text
            source_language: Source language (optional)
            
        Returns:
            Transliteration data
        """
        return self.language_processor.transliterate_only(title, source_language)
    
    def score_language(self, title: str, expected_language: str) -> Dict:
        """
        Score how well a title matches an expected language.
        
        Args:
            title: Title text
            expected_language: Expected language
            
        Returns:
            Language confidence score
        """
        return self.language_processor.score_language(title, expected_language)
    
    def process_single_id(self, eidr_id: str) -> Dict:
        """
        Process a single EIDR ID.
        
        Args:
            eidr_id: EIDR ID to process
            
        Returns:
            Processed data
        """
        result = self.batch_processor.process_single_id(eidr_id)
        return result or {"error": f"Failed to process {eidr_id}"}
    
    def process_id_file(self, file_path: str, output_file: Optional[str] = None,
                        confirm: bool = False) -> Dict:
        """
        Process all EIDR IDs in a file.
        
        Args:
            file_path: Path to the file containing EIDR IDs
            output_file: Path to save results (optional)
            confirm: Whether to ask for user confirmation before processing
            
        Returns:
            Processing results and statistics
        """
        # Load IDs from file
        ids = self.file_processor.get_ids_from_file(file_path)
        if not ids:
            return {"error": f"No IDs found in {file_path}"}
        
        # Ask for confirmation if required
        if confirm:
            proceed = input(f"Process {len(ids)} IDs? (y/n): ").lower()
            if proceed != 'y':
                logger.info("Operation cancelled by user")
                return {"status": "cancelled"}
        
        # Process IDs
        logger.info(f"Processing {len(ids)} IDs from {file_path}")
        results = self.batch_processor.process_batch(ids, output_file)
        
        logger.info(f"Completed processing: {results['processed']} succeeded, {results['failed']} failed")
        return results


# # Example usage
# if __name__ == "__main__":
#     # Initialize SDK with .env file
#     sdk = EIDRSDK(".env")
    
#     # Example 1: Process a single title (language identification)
#     language_info = sdk.identify_language("Le Fabuleux Destin d'Amélie Poulain")
#     print(f"Language identification: {language_info}")
    
#     # Example 2: Process a file of EIDR IDs
#     results = sdk.process_id_file("IDs/ids.txt", "results/results.json")
#     print(f"Processed {results['processed']} IDs, {results['failed']} failed")