const { useState, useEffect } = React;

// Main App Component
const App = () => {
  const [items, setItems] = useState([]);
  const [filteredItems, setFilteredItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [columns, setColumns] = useState([]);
  const [visibleColumns, setVisibleColumns] = useState([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showColumnModal, setShowColumnModal] = useState(false);
  const [currentItem, setCurrentItem] = useState({});
  const [notification, setNotification] = useState({ show: false, message: '', type: '' });
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
  const [filterValues, setFilterValues] = useState({});
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeColumn, setActiveColumn] = useState(null);
  
  const API_BASE_URL = 'http://localhost:3000/api';

  // Fetch all items and table info when component mounts
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Fetch all items
        const itemsResponse = await axios.get(`${API_BASE_URL}/items`);
        console.log('Items fetched:', itemsResponse.data);
        
        if (itemsResponse.data && itemsResponse.data.length > 0) {
          setItems(itemsResponse.data);
          setFilteredItems(itemsResponse.data);
          
          // Extract all unique column names from all items
          const allColumns = new Set();
          itemsResponse.data.forEach(item => {
            Object.keys(item).forEach(key => allColumns.add(key));
          });
          
          // Ensure RecordID and Title come first (they're the primary keys)
          const sortedColumns = Array.from(allColumns).sort((a, b) => {
            if (a === 'RecordID') return -1;
            if (b === 'RecordID') return 1;
            if (a === 'Title') return -1;
            if (b === 'Title') return 1;
            return a.localeCompare(b);
          });
          
          setColumns(sortedColumns);
          setVisibleColumns(sortedColumns); // Initially all columns are visible
          setActiveColumn(sortedColumns[0]); // Set first column as active
          
          // Initialize filter values
          const initialFilterValues = {};
          sortedColumns.forEach(column => {
            initialFilterValues[column] = '';
          });
          setFilterValues(initialFilterValues);
        } else {
          setItems([]);
          setFilteredItems([]);
          
          // Default columns if no data
          const defaultColumns = ['RecordID', 'Title'];
          setColumns(defaultColumns);
          setVisibleColumns(defaultColumns);
          setActiveColumn('RecordID');
        }
      } catch (err) {
        console.error('Error fetching data:', err);
        setError('Failed to load data. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Apply sorting to items
  useEffect(() => {
    let sortedItems = [...filteredItems];
    
    if (sortConfig.key) {
      sortedItems.sort((a, b) => {
        // Handle undefined or null values
        if (a[sortConfig.key] === undefined || a[sortConfig.key] === null) return 1;
        if (b[sortConfig.key] === undefined || b[sortConfig.key] === null) return -1;
        
        // Determine data type for proper sorting
        const aValue = a[sortConfig.key];
        const bValue = b[sortConfig.key];
        
        // String comparison
        if (typeof aValue === 'string' && typeof bValue === 'string') {
          return sortConfig.direction === 'asc' 
            ? aValue.localeCompare(bValue) 
            : bValue.localeCompare(aValue);
        }
        
        // Numeric comparison
        if (typeof aValue === 'number' && typeof bValue === 'number') {
          return sortConfig.direction === 'asc' 
            ? aValue - bValue 
            : bValue - aValue;
        }
        
        // Mixed type comparison (convert to string)
        const aString = String(aValue);
        const bString = String(bValue);
        return sortConfig.direction === 'asc' 
          ? aString.localeCompare(bString) 
          : bString.localeCompare(aString);
      });
    }
    
    setFilteredItems(sortedItems);
  }, [sortConfig]);

  // Apply filters to items
  useEffect(() => {
    const filterItemsByValues = () => {
      return items.filter(item => {
        // Check if item matches all active filters
        return Object.entries(filterValues).every(([column, filterValue]) => {
          // Skip empty filters
          if (!filterValue) return true;
          
          // Handle null or undefined values
          if (item[column] === undefined || item[column] === null) {
            return filterValue === 'null' || filterValue === 'undefined';
          }
          
          // Convert to string for comparison
          const itemValue = typeof item[column] === 'object' 
            ? JSON.stringify(item[column]).toLowerCase() 
            : String(item[column]).toLowerCase();
          
          return itemValue.includes(filterValue.toLowerCase());
        });
      });
    };
    
    const filtered = filterItemsByValues();
    setFilteredItems(filtered);
    
    // Reapply sorting after filtering
    if (sortConfig.key) {
      setSortConfig({ ...sortConfig });
    }
  }, [items, filterValues]);

  // Scroll to column when active column changes
  useEffect(() => {
    if (activeColumn) {
      const columnElement = document.getElementById(`column-header-${activeColumn}`);
      if (columnElement) {
        columnElement.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'start' });
      }
    }
  }, [activeColumn]);

  // Handle adding a new item
  const handleAddItem = async (newItem) => {
    try {
      console.log('Adding new item:', newItem);
      const response = await axios.post(`${API_BASE_URL}/items`, newItem);
      console.log('Add response:', response.data);
      
      setItems([...items, newItem]);
      setShowAddModal(false);
      showNotification('Item created successfully!', 'success');
    } catch (err) {
      console.error('Error adding item:', err);
      showNotification(err.response?.data?.error || 'Failed to add item', 'danger');
    }
  };

// Simplified handleUpdateItem function - no _original needed
const handleUpdateItem = async (updatedItem) => {
    try {
      // Get the RecordID and Title directly from the form data
      const recordID = updatedItem.RecordID;
      const title = updatedItem.Title;
      
      // Make sure we have the RecordID and Title for the API URL
      if (!recordID || !title) {
        console.error('Missing required item data:', { recordID, title });
        showNotification('Update failed: Missing required data', 'danger');
        return;
      }
      
      // Format data for the update
      const recordIDForUrl = encodeURIComponent(String(recordID));
      const titleForUrl = encodeURIComponent(String(title));
      
      console.log('Updating item:', { RecordID: recordID, Title: title });
      
      const updateUrl = `${API_BASE_URL}/items/${recordIDForUrl}/${titleForUrl}`;
      console.log('Update URL:', updateUrl);
      
      // Remove _original from the data sent to the API
      const { _original, ...dataToUpdate } = updatedItem;
      
      const response = await axios.put(updateUrl, dataToUpdate);
      console.log('Update response:', response.data);
      
      // Update the items list with the updated item
      setItems(items.map(item => 
        (item.RecordID === recordID && item.Title === title) 
          ? updatedItem 
          : item
      ));
      
      setShowEditModal(false);
      showNotification('Item updated successfully!', 'success');
    } catch (err) {
      console.error('Error updating item:', err);
      showNotification(err.response?.data?.error || 'Failed to update item', 'danger');
    }
  };

  // Handle deleting an item
  const handleDeleteItem = async (item) => {
    const recordID = item.RecordID;
    const title = item.Title;
    
    if (confirm(`Are you sure you want to delete the item with RecordID: ${recordID} and Title: ${title}?`)) {
      try {
        // Properly encode URL components
        const recordIDForUrl = encodeURIComponent(String(recordID));
        const titleForUrl = encodeURIComponent(String(title));
        
        const deleteUrl = `${API_BASE_URL}/items/${recordIDForUrl}/${titleForUrl}`;
        console.log('Delete URL:', deleteUrl);
        
        const response = await axios.delete(deleteUrl);
        console.log('Delete response:', response.data);
        
        setItems(items.filter(i => 
          !(i.RecordID === recordID && i.Title === title)
        ));
        
        showNotification('Item deleted successfully!', 'success');
      } catch (err) {
        console.error('Error deleting item:', err);
        showNotification(err.response?.data?.error || 'Failed to delete item', 'danger');
      }
    }
  };

  // Handle column visibility toggling
  const handleToggleColumnVisibility = (columnVisibilities) => {
    const newVisibleColumns = columns.filter((col) => columnVisibilities[col]);
    setVisibleColumns(newVisibleColumns);
    
    // Make sure active column is still visible
    if (newVisibleColumns.length > 0 && !newVisibleColumns.includes(activeColumn)) {
      setActiveColumn(newVisibleColumns[0]);
    }
    
    setShowColumnModal(false);
  };

  // Sort handler
  const handleSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  // Filter handler
  const handleFilterChange = (column, value) => {
    setFilterValues({
      ...filterValues,
      [column]: value
    });
  };

  // Reset all filters
  const handleResetFilters = () => {
    const resetFilters = {};
    columns.forEach(column => {
      resetFilters[column] = '';
    });
    setFilterValues(resetFilters);
  };

  // Show notification
  const showNotification = (message, type) => {
    setNotification({ show: true, message, type });
    setTimeout(() => {
      setNotification({ show: false, message: '', type: '' });
    }, 3000);
  };

const openEditModal = (item) => {
    // Create a deep copy of the item
    const itemCopy = JSON.parse(JSON.stringify(item));
    
    // Convert any non-string values to strings for input fields
    Object.keys(itemCopy).forEach(key => {
      if (typeof itemCopy[key] === 'object' && itemCopy[key] !== null) {
        itemCopy[key] = JSON.stringify(itemCopy[key]);
      }
    });
    
    setCurrentItem(itemCopy);
    setShowEditModal(true);
    console.log('Opened edit modal for item', { RecordID: item.RecordID, Title: item.Title });
  };
  // Toggle sidebar
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  // Set active column
  const handleColumnClick = (column) => {
    setActiveColumn(column);
  };

  return (
    <div className="app-container">
      {/* Sidebar for column navigation */}
      <div className={`sidebar ${sidebarOpen ? 'open' : 'closed'}`}>
        <div className="sidebar-header">
          <h6 className="mb-0">Columns</h6>
          <button 
            className="btn btn-sm btn-link p-0 sidebar-toggle" 
            onClick={toggleSidebar}
            title={sidebarOpen ? "Collapse sidebar" : "Expand sidebar"}
          >
            <i className={`bi ${sidebarOpen ? 'bi-chevron-left' : 'bi-chevron-right'}`}></i>
          </button>
        </div>
        
        {sidebarOpen && (
          <div className="sidebar-content">
            <div className="sidebar-item-header">Quick Navigation</div>
            <ul className="column-list">
              {visibleColumns.map(column => (
                <li 
                  key={column} 
                  className={`column-item ${activeColumn === column ? 'active' : ''}`}
                  onClick={() => handleColumnClick(column)}
                >
                  <span className="column-name">{column}</span>
                  {column === 'RecordID' || column === 'Title' ? (
                    <span className="column-badge">Key</span>
                  ) : null}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
      
      {/* Main content */}
      <div className={`main-content ${sidebarOpen ? 'with-sidebar' : 'full-width'}`}>
        <div className="container-fluid px-4">
          <h1 className="mt-4 mb-4">
            <i className="bi bi-database-fill me-2"></i>
            EIDR Language Tool
          </h1>
          
          {notification.show && (
            <div className={`alert alert-${notification.type} d-flex align-items-center`} role="alert">
              <i className={`bi ${notification.type === 'success' ? 'bi-check-circle' : 'bi-exclamation-triangle'} me-2`}></i>
              {notification.message}
            </div>
          )}
          
          <div className="table-container">
            <div className="table-header">
              <h2>
                <i className="bi bi-table me-2"></i>
                AWS DyanmoDB Data
              </h2>
              <div className="d-flex gap-2">
                <button 
                  className="btn btn-secondary" 
                  onClick={() => setShowColumnModal(true)}
                >
                  <i className="bi bi-layout-three-columns me-1"></i>
                  Columns
                </button>
                <button 
                  className="btn btn-primary" 
                  onClick={() => {
                    setCurrentItem({});
                    setShowAddModal(true);
                  }}
                >
                  <i className="bi bi-plus-lg me-1"></i>
                  Add Item
                </button>
              </div>
            </div>
            
            {loading ? (
              <div className="loading-spinner">
                <div className="spinner-border" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
              </div>
            ) : error ? (
              <div className="alert alert-danger d-flex align-items-center" role="alert">
                <i className="bi bi-exclamation-triangle me-2"></i>
                {error}
              </div>
            ) : (
              <>
                <div className="mb-3 d-flex justify-content-between align-items-center">
                  <span className="badge bg-info">
                    <i className="bi bi-eye me-1"></i>
                    Showing {filteredItems.length} of {items.length} items
                  </span>
                  <button 
                    className="btn btn-sm btn-secondary" 
                    onClick={handleResetFilters}
                  >
                    <i className="bi bi-x-circle me-1"></i>
                    Reset Filters
                  </button>
                </div>
  
                <div className="table-responsive">
                  <table className="table">
                    <thead>
                      <tr>
                        {visibleColumns.map(column => (
                          <th 
                            key={column} 
                            scope="col" 
                            id={`column-header-${column}`}
                            className={activeColumn === column ? 'active-column' : ''}
                          >
                            <div 
                              className="d-flex align-items-center" 
                              onClick={() => handleSort(column)}
                              style={{ cursor: 'pointer' }}
                            >
                              {column}
                              {sortConfig.key === column && (
                                <i className={`bi ${sortConfig.direction === 'asc' ? 'bi-sort-up' : 'bi-sort-down'} ms-1`}></i>
                              )}
                            </div>
                            <input
                              type="text"
                              className="form-control form-control-sm mt-1"
                              placeholder="Filter..."
                              value={filterValues[column] || ''}
                              onChange={(e) => handleFilterChange(column, e.target.value)}
                            />
                          </th>
                        ))}
                        <th scope="col">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredItems.length > 0 ? (
                        filteredItems.map((item, index) => (
                          <tr key={`${item.RecordID}-${item.Title}-${index}`}>
                            {visibleColumns.map(column => (
                              <td 
                                key={column}
                                className={activeColumn === column ? 'active-column' : ''}
                              >
                                {typeof item[column] === 'object' 
                                  ? JSON.stringify(item[column]) 
                                  : item[column] !== undefined 
                                    ? String(item[column]) 
                                    : ''}
                              </td>
                            ))}
                            <td>
                              <div className="action-buttons">
                                <button 
                                  className="btn btn-sm btn-outline-primary" 
                                  onClick={() => openEditModal(item)}
                                  title="Edit Item"
                                >
                                  <i className="bi bi-pencil"></i>
                                </button>
                                <button 
                                  className="btn btn-sm btn-outline-danger" 
                                  onClick={() => handleDeleteItem(item)}
                                  title="Delete Item"
                                >
                                  <i className="bi bi-trash"></i>
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={visibleColumns.length + 1} className="text-center py-4">
                            <i className="bi bi-inbox text-light mb-2" style={{ fontSize: '2rem' }}></i>
                            <p className="mb-0">
                              {items.length > 0 
                                ? 'No items match the current filters.' 
                                : 'No items found. Add a new item to get started.'}
                            </p>
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
      
      {/* Add Item Modal */}
      {showAddModal && (
        <ItemModal 
          show={showAddModal} 
          onClose={() => setShowAddModal(false)}
          onSave={handleAddItem}
          item={{}}
          columns={columns}
          title="Add New Item"
        />
      )}
      
      {/* Edit Item Modal */}
      {showEditModal && (
        <ItemModal 
          show={showEditModal} 
          onClose={() => setShowEditModal(false)}
          onSave={handleUpdateItem}
          item={currentItem}
          columns={columns.filter(col => col !== '_original')}
          title="Edit Item"
          editMode={true}
        />
      )}
      
      {/* Column Visibility Modal */}
      {showColumnModal && (
        <ColumnVisibilityModal
          show={showColumnModal}
          onClose={() => setShowColumnModal(false)}
          columns={columns}
          visibleColumns={visibleColumns}
          onSave={handleToggleColumnVisibility}
        />
      )}
    </div>
  );
};

// Updated Modal Component for Add/Edit without _original handling
const ItemModal = ({ show, onClose, onSave, item, columns, title, editMode = false }) => {
    const [formData, setFormData] = useState({...item});
    const [errors, setErrors] = useState({});
    
    // Update formData when item changes
    useEffect(() => {
      setFormData({...item});
    }, [item]);
  
    // Handle field changes
    const handleChange = (e) => {
      const { name, value } = e.target;
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
      
      // Clear error for this field when modified
      if (errors[name]) {
        setErrors(prev => ({
          ...prev,
          [name]: null
        }));
      }
    };
  
    // Parse value based on original type
    const parseValueByOriginalType = (key, value) => {
      if (value === '') return value;
      
      // If we have the original item and can determine the type
      if (item && item[key] !== undefined) {
        const originalType = typeof item[key];
        
        if (originalType === 'number') {
          const parsed = parseFloat(value);
          return isNaN(parsed) ? value : parsed;
        }
        
        // For boolean values
        if (originalType === 'boolean') {
          if (value.toLowerCase() === 'true') return true;
          if (value.toLowerCase() === 'false') return false;
        }
        
        // Try to parse JSON for object types
        if (originalType === 'object') {
          try {
            return JSON.parse(value);
          } catch (e) {
            return value;
          }
        }
      }
      
      // Default: return as is (string)
      return value;
    };
  
    // Handle form submission
    const handleSubmit = (e) => {
      e.preventDefault();
      
      // Validate required fields (RecordID and Title are always required)
      const newErrors = {};
      if (!formData.RecordID) {
        newErrors.RecordID = 'RecordID is required';
      }
      if (!formData.Title) {
        newErrors.Title = 'Title is required';
      }
      
      if (Object.keys(newErrors).length > 0) {
        setErrors(newErrors);
        return;
      }
      
      // Convert values back to their proper types
      const processedFormData = {};
      Object.keys(formData).forEach(key => {
        processedFormData[key] = parseValueByOriginalType(key, formData[key]);
      });
      
      // If validation passes, save the item
      onSave(processedFormData);
    };
  
    return (
      <div className={`modal ${show ? 'd-block' : ''}`} tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
        <div className="modal-dialog modal-lg">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">
                <i className={`bi ${editMode ? 'bi-pencil' : 'bi-plus-circle'} me-2`}></i>
                {title}
              </h5>
              <button type="button" className="btn-close" onClick={onClose}></button>
            </div>
            <div className="modal-body">
              <form onSubmit={handleSubmit}>
                {columns.map(column => (
                  <div className="form-group mb-3" key={column}>
                    <label htmlFor={column} className={column === 'RecordID' || column === 'Title' ? 'required-field' : ''}>
                      {column}
                    </label>
                    <input
                      type="text"
                      className={`form-control ${errors[column] ? 'is-invalid' : ''}`}
                      id={column}
                      name={column}
                      value={formData[column] !== undefined ? formData[column] : ''}
                      onChange={handleChange}
                      disabled={editMode && (column === 'RecordID' || column === 'Title')}
                    />
                    {errors[column] && (
                      <div className="invalid-feedback">
                        {errors[column]}
                      </div>
                    )}
                  </div>
                ))}
              </form>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
              <button type="button" className="btn btn-primary" onClick={handleSubmit}>
                <i className={`bi ${editMode ? 'bi-check-lg' : 'bi-plus-lg'} me-1`}></i>
                {editMode ? 'Update' : 'Create'}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

// Column Visibility Modal
const ColumnVisibilityModal = ({ show, onClose, columns, visibleColumns, onSave }) => {
  const [columnVisibility, setColumnVisibility] = useState({});
  
  // Initialize column visibility state
  useEffect(() => {
    const initialVisibility = {};
    columns.forEach(column => {
      initialVisibility[column] = visibleColumns.includes(column);
    });
    setColumnVisibility(initialVisibility);
  }, [columns, visibleColumns]);
  
  // Handle checkbox change
  const handleCheckboxChange = (column) => {
    setColumnVisibility(prev => ({
      ...prev,
      [column]: !prev[column]
    }));
  };
  
  // Handle save button click
  const handleSave = () => {
    // Ensure at least RecordID and Title are always visible
    const updatedVisibility = { ...columnVisibility };
    if (columns.includes('RecordID')) updatedVisibility.RecordID = true;
    if (columns.includes('Title')) updatedVisibility.Title = true;
    
    onSave(updatedVisibility);
  };

  return (
    <div className={`modal ${show ? 'd-block' : ''}`} tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">
              <i className="bi bi-layout-three-columns me-2"></i>
              Column Visibility
            </h5>
            <button type="button" className="btn-close" onClick={onClose}></button>
          </div>
          <div className="modal-body">
            <div className="mb-3">
              <p>Select columns to display in the table:</p>
              <div className="d-grid gap-2">
                {columns.map(column => (
                  <div className="form-check" key={column}>
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id={`column-visibility-${column}`}
                      checked={columnVisibility[column] || false}
                      onChange={() => handleCheckboxChange(column)}
                      disabled={column === 'RecordID' || column === 'Title'} // Primary keys are always visible
                    />
                    <label className="form-check-label" htmlFor={`column-visibility-${column}`}>
                      {column}
                      {(column === 'RecordID' || column === 'Title') && 
                        <span className="text-muted"> (required)</span>}
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
            <button type="button" className="btn btn-primary" onClick={handleSave}>
              <i className="bi bi-check-lg me-1"></i>
              Apply
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Render the app
ReactDOM.render(<App />, document.getElementById('app'));