// app.js - Main server file
const express = require('express');
const { DynamoDBClient, DescribeTableCommand } = require('@aws-sdk/client-dynamodb');
const { 
  DynamoDBDocumentClient, 
  ScanCommand, 
  GetCommand, 
  PutCommand, 
  DeleteCommand 
} = require('@aws-sdk/lib-dynamodb');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const port = 3000;
require('dotenv').config();

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

// Configure AWS
const dynamoClient = new DynamoDBClient({ 
  region: 'us-east-2',
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
  }
});

// Create DynamoDB Document client
const dynamoDB = DynamoDBDocumentClient.from(dynamoClient);
const tableName = 'TitleLanguageData';

// Route to get table schema information
app.get('/api/table-info', async (req, res) => {
  try {
    const command = new DescribeTableCommand({
      TableName: tableName
    });
    
    const tableInfo = await dynamoClient.send(command);
    res.json({
      tableName,
      keySchema: tableInfo.Table.KeySchema,
      attributeDefinitions: tableInfo.Table.AttributeDefinitions
    });
  } catch (error) {
    console.error("Error getting table info:", error);
    res.status(500).json({ error: "Could not get table info" });
  }
});

// Route to get all items
app.get('/api/items', async (req, res) => {
  try {
    const command = new ScanCommand({
      TableName: tableName
    });
    
    const data = await dynamoDB.send(command);
    res.json(data.Items);
  } catch (error) {
    console.error("Error fetching items:", error);
    res.status(500).json({ error: "Could not fetch items" });
  }
});

// Route to get a single item by RecordID and Title
app.get('/api/items/:recordID/:title', async (req, res) => {
  try {
    const command = new GetCommand({
      TableName: tableName,
      Key: {
        RecordID: req.params.recordID,
        Title: req.params.title
      }
    });
    
    const data = await dynamoDB.send(command);
    if (data.Item) {
      res.json(data.Item);
    } else {
      res.status(404).json({ error: "Item not found" });
    }
  } catch (error) {
    console.error("Error fetching item:", error);
    res.status(500).json({ error: "Could not fetch the item" });
  }
});

// Route to create a new item
app.post('/api/items', async (req, res) => {
  try {
    // Ensure required key fields are present
    if (!req.body.RecordID || !req.body.Title) {
      return res.status(400).json({ 
        error: "Both RecordID and Title fields are required" 
      });
    }
    
    // Check if item already exists (to prevent accidental overwrites)
    const getCommand = new GetCommand({
      TableName: tableName,
      Key: {
        RecordID: req.body.RecordID,
        Title: req.body.Title
      }
    });
    
    const existingItem = await dynamoDB.send(getCommand);
    
    if (existingItem.Item) {
      return res.status(409).json({ 
        error: "An item with this RecordID and Title already exists. Use PUT to update." 
      });
    }
    
    const command = new PutCommand({
      TableName: tableName,
      Item: req.body
    });
    
    await dynamoDB.send(command);
    res.status(201).json({
      message: "Item created successfully",
      item: req.body
    });
  } catch (error) {
    console.error("Error creating item:", error);
    res.status(500).json({ error: "Could not create the item" });
  }
});

// Route to update an item
app.put('/api/items/:recordID/:title', async (req, res) => {
  try {
    console.log("Updating item with RecordID:", req.params.recordID, "and Title:", req.params.title);
    console.log("Update data:", req.body);
    
    // First, check if the item exists
    const getCommand = new GetCommand({
      TableName: tableName,
      Key: {
        RecordID: req.params.recordID,
        Title: req.params.title
      }
    });
    
    const existingItem = await dynamoDB.send(getCommand);
    
    if (!existingItem.Item) {
      return res.status(404).json({ 
        error: "Item not found. Cannot update a non-existent item." 
      });
    }
    
    // Ensure key fields match the URL parameters (and are not modified)
    const item = { ...req.body };
    item.RecordID = req.params.recordID;
    item.Title = req.params.title;
    
    const command = new PutCommand({
      TableName: tableName,
      Item: item
    });
    
    await dynamoDB.send(command);
    res.json({
      message: "Item updated successfully",
      item: item
    });
  } catch (error) {
    console.error("Error updating item:", error);
    res.status(500).json({ error: "Could not update the item" });
  }
});

// Route to delete using RecordID and Title (matching table's composite key)
app.delete('/api/items/:recordID/:title', async (req, res) => {
  try {
    console.log("Deleting item with RecordID:", req.params.recordID, "and Title:", req.params.title);
    
    if (!req.params.recordID || !req.params.title) {
      return res.status(400).json({ 
        error: "Both RecordID and Title parameters are required" 
      });
    }
    
    const command = new DeleteCommand({
      TableName: tableName,
      Key: {
        RecordID: req.params.recordID,
        Title: req.params.title
      }
    });
    
    await dynamoDB.send(command);
    res.json({ 
      message: "Item deleted successfully",
      deletedKey: {
        RecordID: req.params.recordID,
        Title: req.params.title
      }
    });
  } catch (error) {
    console.error("Error deleting item:", error);
    res.status(500).json({ 
      error: "Could not delete the item",
      details: error.message
    });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});